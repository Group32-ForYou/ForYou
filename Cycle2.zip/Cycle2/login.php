<?php
session_start();
include('db_connection.php');

// Hardcoded therapist credentials
$therapist_email = 'monicagreen@app.com';
$therapist_password = 'monicagreen123';

// Capture form data from the login form
$email = $_POST['email'] ?? null;
$password = $_POST['password'] ?? null;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // First, check if it's therapist login (hardcoded)
    if ($email === $therapist_email && $password === $therapist_password) {
        // Set therapist session and redirect to therapist dashboard
        $_SESSION['user'] = 'therapist';
        header('Location: therapist-dashboard.html');
        exit();
    }

    // For patients, check the database for matching email
    $stmt = $conn->prepare("SELECT id, password, first_name FROM user WHERE email = ?");
    $stmt->bind_param('s', $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        // User exists, fetch the data
        $stmt->bind_result($id, $hashed_password, $first_name);
        $stmt->fetch();

        // Verify the password
        if (password_verify($password, $hashed_password)) {
            // Set patient session
            $_SESSION['user'] = 'patient';
            $_SESSION['user_id'] = $id;  // Save user ID for future use
            $_SESSION['first_name'] = $first_name;  // Save first name in session

            // Redirect to patient dashboard
            header('Location: patient-dashboard.php');
            exit();
        } else {
            // Invalid password
            echo "<script>alert('Invalid password. Please try again.');window.location.href='login.html';</script>";
        }
    } else {
        // No user found with the provided email
        echo "<script>alert('No user found with this email. Please try again.');window.location.href='login.html';</script>";
    }

    $stmt->close();
} else {
    // If the request method is not POST, redirect back to login form
    header('Location: login.html');
    exit();
}

// Close the database connection
$conn->close();
?>

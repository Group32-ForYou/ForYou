<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'db_connection.php';

$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['patient_id']) && isset($data['doctor_id']) && isset($data['appointment_date']) && isset($data['appointment_time'])) {
    $patient_id = $data['patient_id'];
    $doctor_id = $data['doctor_id'];
    $appointment_date = $data['appointment_date'];
    $appointment_time = $data['appointment_time'];
    $status = 'Upcoming';

    $sql = "INSERT INTO appointments (patient_id, doctor_id, appointment_date, appointment_time, status) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('iisss', $patient_id, $doctor_id, $appointment_date, $appointment_time, $status);

    if ($stmt->execute()) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Failed to save appointment']);
    }
    $stmt->close();
} else {
    echo json_encode(['status' => 'error', 'message' => 'Missing required data']);
}

$conn->close();
?>

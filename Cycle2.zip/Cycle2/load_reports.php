<?php
// Database connection
$conn = new mysqli("localhost", "root", "", "foryou_uploadreport");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch uploaded reports
$sql = "SELECT report_name, upload_date FROM reports";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Output data of each row
    while ($row = $result->fetch_assoc()) {
        echo "<tr>
                <td>" . htmlspecialchars($row['report_name']) . "</td>
                <td>" . htmlspecialchars($row['upload_date']) . "</td>
              </tr>";
    }
} else {
    echo "<tr><td colspan='2'>No reports uploaded yet.</td></tr>";
}

$conn->close();
?>

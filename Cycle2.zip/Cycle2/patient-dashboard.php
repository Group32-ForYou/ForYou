<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard</title>
    <link rel="stylesheet" href="./styles/patient-dashboard.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>

<nav>
    <h1><a href="foryou.html">ForYou</a></h1>
    <ul>
        <li><a href="patient-dashboard.php">Overview</a></li>
        <li><a href="appointment.html">Appointments</a></li>
        <li><a href="tracker.html">Tracker</a></li>
        <li><a href="doctor-availability.html">Doctor Availability</a></li>
    </ul>
</nav>

<!-- Daily Log Section -->
<div class="log-cards">
    <div class="log-card">
        <i class="fas fa-bed"></i>
        <h3>Hours Slept</h3>
        <p id="hours_slept"></p>
    </div>
    <div class="log-card">
        <i class="fas fa-smile"></i>
        <h3>Mood</h3>
        <p id="mood"></p>
    </div>
    <div class="log-card">
        <i class="fas fa-walking"></i>
        <h3>Activities</h3>
        <p id="activities"></p>
    </div>
    <div class="log-card">
        <i class="fas fa-apple-alt"></i>
        <h3>Diet</h3>
        <p id="diet"></p>
    </div>
    <div class="log-card">
        <i class="fas fa-bicycle"></i>
        <h3>Exercise</h3>
        <p id="exercise"></p>
    </div>
</div>

<!-- Appointments Section -->
<div class="appointments">
    <h2>Appointments</h2>
    <table>
         <thead>
        <tr>
            <th>Doctor</th>
            <th>Specialization</th>
            <th>Date</th>
            <th>Time</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody id="appointments-body">
        <?php
        // Start PHP code block to fetch appointments
        session_start(); // Ensure session is started to access email

        // Check if session email is set
        if (isset($_SESSION['email'])) {
            $conn = new mysqli("localhost", "root", "", "foryou");

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Query to get appointments by email
            $email = $_SESSION['email'];
            $query = "SELECT * FROM appointments WHERE email = ?";
            $stmt = $conn->prepare($query);
            $stmt->bind_param('s', $email);
            $stmt->execute();
            $result = $stmt->get_result();

            if ($result && $result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                            <td>" . htmlspecialchars($row['doctor_name']) . "</td>
                            <td>" . htmlspecialchars($row['specialization']) . "</td>
                            <td>" . htmlspecialchars($row['appointment_date']) . "</td>
                            <td>" . htmlspecialchars($row['appointment_time']) . "</td>
                            <td><span class='status " . strtolower($row['status']) . "'>" . htmlspecialchars($row['status']) . "</span></td>
                          </tr>";
                }
            } else {
                echo "<tr><td colspan='5'>No appointments found</td></tr>";
            }
            
            $stmt->close();
            $conn->close();
        } else {
            echo "<tr><td colspan='5'>Please log in to see your appointments</td></tr>";
        }
        ?>
    </tbody>
    </table>
</div>

<!-- Report Section -->
<div class="reports">
    <h2>My Previous Reports</h2>
    <form action="uploadreport.php" method="post" enctype="multipart/form-data">
        <input type="file" name="fileToUpload" id="fileToUpload" required>
        <input type="submit" value="Upload Report" name="submit" class="upload-btn">
    </form>

    <table>
        <thead>
            <tr>
                <th>Report Name</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
        <?php
        // Start PHP code block to fetch reports from database
        $conn = new mysqli("localhost", "root", "", "foryou_uploadreport");

        // Check connection
        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        // Fetch uploaded reports
        $sql = "SELECT report_name, upload_date FROM reports";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . htmlspecialchars($row['report_name']) . "</td>
                        <td>" . htmlspecialchars($row['upload_date']) . "</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='2'>No reports uploaded yet.</td></tr>";
        }

        $conn->close();
        ?>
        </tbody>
    </table>
</div>

</body>
</html>

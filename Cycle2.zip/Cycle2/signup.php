<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('db_connection.php');

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture form data
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = $_POST['password'];
    $gender = $_POST['gender'];
    $dob = $_POST['dob'];

    // Insert into database
    $sql = "INSERT INTO user (first_name, last_name, email, password, phone, gender, dob) 
            VALUES ('$first_name', '$last_name', '$email', '$password', '$phone', '$gender', '$dob')";

    if (mysqli_query($conn, $sql)) {
        // Show modal and redirect after a short delay
        echo "<script>
                window.onload = function() { 
                    showModalAndRedirect(); // Show the pop-up and redirect
                }
              </script>";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    echo "Please submit the form.";
}
?>

<!-- Include the modal code and script for showing the modal and redirecting -->
<script>
    function showModalAndRedirect() {
        // Create the modal HTML structure
        const modalHtml = `
            <div id="signupModal" style="position: fixed; z-index: 100; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); display: flex; justify-content: center; align-items: center;">
                <div style="background: white; padding: 20px; border-radius: 10px; text-align: center;">
                    <h2>Successfully Signed Up!</h2>
                    <p>You will be redirected to the login page shortly.</p>
                </div>
            </div>
        `;

        // Add the modal to the body
        document.body.innerHTML += modalHtml;

        // Wait for a few seconds and then redirect
        setTimeout(function() {
            window.location.href = 'login.html';
        }, 3000); // Redirect after 3 seconds
    }
</script>

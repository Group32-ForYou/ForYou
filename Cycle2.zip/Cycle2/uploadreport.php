<?php
// Enable error reporting for debugging purposes
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

if (isset($_POST['submit'])) {
    // Database connection
    $conn = new mysqli("localhost", "root", "", "foryou_uploadreport");

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


    // Upload directory
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
    $uploadOk = 1;

    // Check if file already exists (Optional, you can remove this if you want)
    if (file_exists($target_file)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Check file size (limit to 5MB)
    if ($_FILES["fileToUpload"]["size"] > 5000000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Check file type (optional but recommended)
    $fileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));
    $allowedTypes = ['pdf', 'doc', 'docx', 'jpg', 'png']; // Adjust as per your needs
    if (!in_array($fileType, $allowedTypes)) {
        echo "Sorry, only PDF, DOC, DOCX, JPG, and PNG files are allowed.";
        $uploadOk = 0;
    }

    // If everything is ok, try to upload the file
    if ($uploadOk == 1) {
        if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
            // File has been uploaded, now insert its info into the database
            $report_name = basename($_FILES["fileToUpload"]["name"]);
            $upload_date = date("Y-m-d H:i:s");
            $sql = "INSERT INTO reports (report_name, upload_date, file_path) VALUES ('$report_name', '$upload_date', '$target_file')";

            if ($conn->query($sql) === TRUE) {
                // Successful upload and database insertion, now redirect back to the dashboard
                header("Location: patient-dashboard.php");
                exit(); // Make sure to exit after the header redirect to stop further code execution
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    $conn->close();
}

window.onload = function() {
    // Create an XMLHttpRequest object
    var xhttp = new XMLHttpRequest();

    // Define the function to be executed when the request is completed
    xhttp.onreadystatechange = function() {
        if (this.readyState == 4 && this.status == 200) {
            document.getElementById("reportTableBody").innerHTML = this.responseText;
        }
    };

    // Make the request to load_reports.php
    xhttp.open("GET", "load_reports.php", true);
    xhttp.send();
};

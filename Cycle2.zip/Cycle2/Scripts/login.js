function toggleLogin(type) {
    document.getElementById('loginTitle').textContent = type === 'patient' ? 'Patient Login' : 'Therapist Login';
    document.querySelector('.toggle-buttons .active').classList.remove('active');
    document.getElementById(type + 'Btn').classList.add('active');
}

// Get the modal
var modal = document.getElementById("popupModal");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on <span> (x), close the modal
span.onclick = function() {
  modal.style.display = "none";
}

// Close the modal if the user clicks outside of it
window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}

// Function to show the modal and redirect after 3 seconds
function showModalAndRedirect() {
  modal.style.display = "block"; // Show the modal
  
  // After 3 seconds, redirect to login.html
  setTimeout(function() {
    window.location.href = 'login.html';
  }, 3000); // 3000ms = 3 seconds
}



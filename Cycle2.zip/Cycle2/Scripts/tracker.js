document.getElementById('submitJournalBtn').addEventListener('click', function () {
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'save_journal.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

    var user_id = document.getElementById('user_id').value;
    var exercise = document.getElementById('exercise').value;
    var sleep = document.getElementById('sleep').value;
    var diet = document.getElementById('diet').value;
    var activities = document.getElementById('activities').value;
    var mood = document.getElementById('mood').value;

    xhr.onload = function () {
        if (xhr.status === 200) {
            // Show success message
            alert('Journal entry saved successfully!');
        } else {
            alert('Failed to save journal entry.');
        }
    };

    xhr.send(
        'user_id=' + encodeURIComponent(user_id) +
        '&exercise=' + encodeURIComponent(exercise) +
        '&sleep=' + encodeURIComponent(sleep) +
        '&diet=' + encodeURIComponent(diet) +
        '&activities=' + encodeURIComponent(activities) +
        '&mood=' + encodeURIComponent(mood)
    );
});
